<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Submission Successful</title>

<style>
body {
  font-family: Arial, sans-serif;
  background: #f4f4f4;
  margin: 0;
}

.container {
  max-width: 500px;
  margin: 80px auto;
  background: #fff;
  padding: 25px;
  border-radius: 10px;
  text-align: center;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

h2 {
  color: #28a745;
}

p {
  font-size: 16px;
  line-height: 1.6;
}

.btn {
  display: inline-block;
  margin-top: 20px;
  padding: 12px 20px;
  background: #007bff;
  color: white;
  text-decoration: none;
  border-radius: 6px;
}

.btn:hover {
  background: #0056b3;
}

.btn-secondary {
  background: #6c757d;
}

.btn-secondary:hover {
  background: #5a6268;
}
</style>

</head>

<body>

<div class="container">
  <h2>Submission Successful ✅</h2>

  <p>Thank you for your interest in renting the CETREE facility.</p>

  <p>We will provide confirmation shortly via email. Our staff are currently reviewing your application carefully.</p>

  <p>If you have any questions or wish to cancel your event, please contact us at <strong>012-3456789</strong>.</p>

  <a href="First_Page.php" class="btn">Back to Home</a>
  <br>
  <a href="Form_Page.php" class="btn btn-secondary">Make Another Booking</a>
</div>

</body>
</html>