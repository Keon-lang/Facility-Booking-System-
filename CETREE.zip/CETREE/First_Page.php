<!DOCTYPE html>
<html>
<head>
  <title>Welcome</title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <style>
    body {
      background-image: url("Dewann.jpeg");
      background-size: cover;
      background-repeat: no-repeat;
      text-align: center;
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 20px;
      color: white;
      background-color: rgba(0,0,0,0.5);
      background-blend-mode: darken;
    }

    p {
      font-size: 20px;
    }

    .icons img {
      margin: 10px;
      border-radius: 10px;
      transition: 0.3s;
      width: 120px;
      max-width: 100%;
      height: auto;
    }

    .icons img:hover {
      transform: scale(1.1);
    }

    .button {
      display: inline-block;
      margin-top: 20px;
      padding: 12px 24px;
      background-color: #007BFF;
      color: white;
      text-decoration: none;
      border-radius: 8px;
      font-size: 16px;
    }

    .button:hover {
      background-color: #0056b3;
    }

    @media (max-width: 600px) {
      p {
        font-size: 16px;
      }
    }
  </style>
</head>

<body>

<h2>Welcome to CETREE Facility</h2>
<p>Feel free to use our hospitality for your event</p>

<div class="icons">
  <a href="https://cetree.usm.my/">
    <img src="Cetree.JPG" alt="CETREE">
  </a>

  <a href="https://www.facebook.com/CetreeOfficial">
    <img src="Facebook.png" alt="Facebook">
  </a>

  <a href="https://www.instagram.com/cetreeusm/">
    <img src="Instagram.png" alt="Instagram">
  </a>
</div>

<br>

<a href="Form_Page.php" class="button">Continue</a>

</body>
</html>
