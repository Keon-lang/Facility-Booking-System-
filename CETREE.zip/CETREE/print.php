<?php
$conn = mysqli_connect("localhost", "root", "", "cetree_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$id = $_GET['id'] ?? 0;

$sql = "SELECT * FROM bookings WHERE id = $id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("Record not found");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Print Booking</title>

<style>
body {
  font-family: Arial, sans-serif;
  margin: 20px;
}

.container {
  max-width: 700px;
  margin: auto;
}

h2 {
  text-align: center;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
}

td {
  border: 1px solid #000;
  padding: 10px;
}

.label {
  font-weight: bold;
  width: 40%;
}

@media print {
  button {
    display: none;
  }
}
</style>

</head>

<body onload="window.print()">

<div class="container">

<h2>Booking Details</h2>

<table>
  <tr>
    <td class="label">Name</td>
    <td><?php echo $row['full_name']; ?></td>
  </tr>
  <tr>
    <td class="label">Phone</td>
    <td><?php echo $row['phone']; ?></td>
  </tr>
  <tr>
    <td class="label">Email</td>
    <td><?php echo $row['email']; ?></td>
  </tr>
  <tr>
    <td class="label">Event Name</td>
    <td><?php echo $row['event_name']; ?></td>
  </tr>
  <tr>
    <td class="label">Date</td>
    <td><?php echo $row['event_date']; ?></td>
  </tr>
  <tr>
    <td class="label">Time</td>
    <td><?php echo $row['event_time']; ?></td>
  </tr>
  <tr>
    <td class="label">Organization</td>
    <td><?php echo $row['organization']; ?></td>
  </tr>
  <tr>
    <td class="label">Facility</td>
    <td><?php echo $row['facility']; ?></td>
  </tr>
  <tr>
    <td class="label">Description</td>
    <td><?php echo $row['description']; ?></td>
  </tr>
  <tr>
    <td class="label">Status</td>
    <td><?php echo $row['status']; ?></td>
  </tr>
</table>

<br>

<button onclick="window.print()">Print Again</button>

</div>

</body>
</html>

<?php mysqli_close($conn); ?>