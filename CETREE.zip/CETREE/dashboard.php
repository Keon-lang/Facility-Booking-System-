<?php
$conn = mysqli_connect("localhost", "root", "", "cetree_db");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

/* -------------------------
   HANDLE APPROVE / REJECT
--------------------------*/
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $action = $_GET['action'];

    if ($action == "approve") {
        $status = "Approved";
    } elseif ($action == "reject") {
        $status = "Rejected";
    } else {
        $status = "Pending";
    }

    mysqli_query($conn, "UPDATE bookings SET status='$status' WHERE id=$id");

    header("Location: dashboard.php");
    exit();
}

/* -------------------------
   SEARCH + DATE FILTER
--------------------------*/
$search = $_GET['search'] ?? '';
$date_filter = $_GET['date'] ?? '';

$where = [];

if (!empty($search)) {
    $where[] = "(full_name LIKE '%$search%' 
                OR event_name LIKE '%$search%' 
                OR facility LIKE '%$search%' 
                OR status LIKE '%$search%')";
}

if (!empty($date_filter)) {
    $where[] = "event_date = '$date_filter'";
}

$where_sql = "";
if (count($where) > 0) {
    $where_sql = "WHERE " . implode(" AND ", $where);
}

$sql = "SELECT * FROM bookings $where_sql ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Staff Dashboard</title>

<!-- AUTO REFRESH -->
<meta http-equiv="refresh" content="10">

<style>
body {
  font-family: Arial, sans-serif;
  background: #f4f4f4;
  margin: 0;
}

.container {
  width: 95%;
  margin: 20px auto;
  background: #fff;
  padding: 20px;
  border-radius: 10px;
  overflow-x: auto;
}

h2 {
  text-align: center;
}

.search-box {
  text-align: center;
  margin-bottom: 15px;
}

input[type="text"], input[type="date"] {
  padding: 10px;
  margin: 5px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

button {
  padding: 10px 15px;
  border: none;
  background: #007bff;
  color: white;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background: #0056b3;
}

table {
  width: 100%;
  border-collapse: collapse;
  margin-top: 20px;
  min-width: 1200px;
}

th, td {
  border: 1px solid #ddd;
  padding: 10px;
  font-size: 14px;
  vertical-align: top;
}

th {
  background: #007bff;
  color: white;
}

tr:nth-child(even) {
  background: #f9f9f9;
}

.btn {
  padding: 5px 10px;
  text-decoration: none;
  border-radius: 5px;
  color: white;
  font-size: 12px;
  margin-right: 5px;
}

.approve {
  background: green;
}

.reject {
  background: red;
}

.status {
  padding: 5px 10px;
  border-radius: 5px;
  color: white;
  font-size: 12px;
}

.Pending { background: orange; }
.Approved { background: green; }
.Rejected { background: red; }
</style>

</head>

<body>

<div class="container">

<h2>Staff Dashboard - Booking Requests</h2>

<!-- SEARCH + DATE FILTER -->
<div class="search-box">
  <form method="GET">

    <input type="text" name="search" placeholder="Search (name/event/facility/status)" 
    value="<?php echo $search; ?>">

    <input type="date" name="date" value="<?php echo $date_filter; ?>">

    <button type="submit">Filter</button>
  </form>
</div>

<table>
<tr>
  <th>ID</th>
  <th>Name</th>
  <th>Phone</th>
  <th>Email</th>
  <th>Event</th>
  <th>Date</th>
  <th>Time</th>
  <th>Organization</th>
  <th>Facility</th>
  <th>Description</th>
  <th>Status</th>
  <th>Action</th>
</tr>

<?php while ($row = mysqli_fetch_assoc($result)) { ?>
<tr>
  <td><?php echo $row['id']; ?></td>
  <td><?php echo $row['full_name']; ?></td>
  <td><?php echo $row['phone']; ?></td>
  <td><?php echo $row['email']; ?></td>
  <td><?php echo $row['event_name']; ?></td>
  <td><?php echo $row['event_date']; ?></td>
  <td><?php echo $row['event_time']; ?></td>
  <td><?php echo $row['organization']; ?></td>
  <td><?php echo $row['facility']; ?></td>

  <!-- DESCRIPTION -->
  <td><?php echo $row['description']; ?></td>

  <td>
    <span class="status <?php echo $row['status']; ?>">
      <?php echo $row['status']; ?>
    </span>
  </td>

  <td>
    <a href="?action=approve&id=<?php echo $row['id']; ?>" class="btn approve">Approve</a>
    <a href="?action=reject&id=<?php echo $row['id']; ?>" class="btn reject">Reject</a>
    <a href="print.php?id=<?php echo $row['id']; ?>" class="btn" style="background:#17a2b8;">
  Print
</a>
  </td>
</tr>
<?php } ?>

</table>

</div>

</body>
</html>

<?php mysqli_close($conn); ?>