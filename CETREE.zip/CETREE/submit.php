<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Submission Successful</title>

<?php
// Database connection
$conn = mysqli_connect("localhost", "root", "", "cetree_db");

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get form data (elak undefined error)
$name = $_POST['full_name'] ?? '';
$phone = $_POST['phone'] ?? '';
$email = $_POST['email'] ?? '';
$event = $_POST['event_name'] ?? '';
$date = $_POST['event_date'] ?? '';
$time = $_POST['event_time'] ?? '';
$org = $_POST['organization'] ?? '';
$facility = $_POST['facility'] ?? '';
$desc = $_POST['description'] ?? '';

// Prepared statement (SECURE)
$stmt = $conn->prepare("INSERT INTO bookings 
(full_name, phone, email, event_name, event_date, event_time, organization, facility, description)
VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("sssssssss", $name, $phone, $email, $event, $date, $time, $org, $facility, $desc);

// Execute
if ($stmt->execute()) {
    // Redirect ke success page
    header("Location: success.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

// Close connection
$stmt->close();
$conn->close();
?>

<style>
body {
  font-family: Arial, sans-serif;
  background: #f4f4f4;
  margin: 0;
}

.container {
  max-width: 500px;
  margin: 80px auto;
  background: #fff;
  padding: 25px;
  border-radius: 10px;
  text-align: center;
}

h2 {
  color: #28a745;
}

p {
  font-size: 16px;
  line-height: 1.5;
}

a {
  display: inline-block;
  margin-top: 20px;
  padding: 10px 20px;
  background: #007bff;
  color: white;
  text-decoration: none;
  border-radius: 5px;
}

a:hover {
  background: #0056b3;
}
</style>

</head>

<body>

<div class="container">
  <h2>Submission Successful ✅</h2>

  <p>Thank you for your interest in renting the CETREE facility.</p>

  <p>We will provide confirmation shortly via email. Our staff are currently reviewing your application carefully.</p>

  <p>If you have any questions, require clarification, or wish to cancel your event, please contact our staff at <strong>012-3456789</strong>.</p>

  <a href="First_Page.php">Back to Home</a>
</div>

</body>
</html>