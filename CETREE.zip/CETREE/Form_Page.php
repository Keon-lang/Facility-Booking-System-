<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Form Page</title>

<style>
body {
  font-family: Arial, sans-serif;
  background: #f4f4f4;
  margin: 0;
}

.container {
  max-width: 500px;
  margin: 30px auto;
  background: #fff;
  padding: 20px;
  border-radius: 10px;
}

h2 {
  text-align: center;
}

input, select, textarea {
  width: 100%;
  padding: 10px;
  margin-top: 8px;
  margin-bottom: 15px;
  border-radius: 5px;
  border: 1px solid #ccc;
}

input[type="submit"] {
  background: #28a745;
  color: white;
  border: none;
}

input[type="reset"] {
  background: #dc3545;
  color: white;
  border: none;
}

input[type="submit"]:hover {
  background: #218838;
}

input[type="reset"]:hover {
  background: #c82333;
}
</style>

</head>

<body>

<div class="container">
  <h2>FORM PAGE</h2>

  <form action="submit.php" method="post">

    <label>Name</label>
    <input type="text" name="full_name" placeholder="Your Name..." required>

    <label>Contact No</label>
    <input type="tel" name="phone" placeholder="Your Contact..." required>

    <label>Office Contact</label>
    <input type="tel" name="Office" placeholder="Office Contact..." required>

    <label>Email</label>
    <input type="email" name="email" placeholder="Enter Your Email" required>

    <label>Event Name</label>
    <input type="text" name="event_name" placeholder="Your Event Name.." required>

    <label>Date</label>
    <input type="date" name="event_date" required>

    <label>Event Start</label>
    <input type="time" name="event_time" required>

    <label>Event End</label>
    <input type="time" name="event_end" required>

    <label>Organization Name</label>
    <input type="text" name="organization" placeholder="Your Organization Name" required>

    <label>Facility</label>
    <select name="facility">
      <option>Dewan Seminar</option>
      <option>Bilik Mesyuarat</option>
      <option>Foyer Aras 1</option>
    </select>

    <label>Description Event</label>
    <textarea name="description" placeholder="Write something..." style="height:150px;"></textarea>

    <label>thank you for your</label>
    <input type="checkbox" name="option_name" value="option_value">


    <input type="submit" value="Submit">
    <input type="reset" value="Reset">

  </form>
</div>

</body>
</html>