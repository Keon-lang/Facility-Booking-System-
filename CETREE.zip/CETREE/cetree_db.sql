-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 01, 2026 at 04:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cetree_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `event_name` varchar(100) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `event_time` time DEFAULT NULL,
  `organization` varchar(100) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `status` varchar(20) DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `full_name`, `phone`, `email`, `event_name`, `event_date`, `event_time`, `organization`, `facility`, `description`, `status`) VALUES
(1, 'KHAIRUL ANWAR', '012-5444665', 'akajihadist@gmail.com', 'Dinner', '2026-03-31', '23:04:00', 'Eureka', 'Dewan Seminar', 'annual dinner for final year student ', 'Approved'),
(2, 'KHAIRUL ANWAR', '012-5444665', 'akajihadist@gmail.com', 'Dinner', '2026-03-31', '23:04:00', 'Eureka', 'Dewan Seminar', 'annual dinner for final year student ', 'Rejected'),
(4, 'the', '65868975', 'akajihadist@gmail.com', 'Lunch Hour ', '2026-03-31', '12:17:00', 'Eureka', 'Dewan Seminar', 'Annual Lunch for our staff', 'Approved'),
(5, 'KHAIRUL ANWAR', '001438981247', 'akajihadist@gmail.com', 'Dinner', '2026-03-30', '23:36:00', 'Eureka', 'Dewan Seminar', 'annual dinner ', 'Rejected'),
(6, 'KHAIRUL ANWAR', '012-5444665', 'akajihadist@gmail.com', 'dinner', '2026-03-31', '14:31:00', 'Eureka', 'Dewan Seminar', 'final year student dinner', 'Pending'),
(7, 'KHAIRUL ANWAR', '012-5444665', 'akajihadist@gmail.com', 'Dinner', '2026-03-31', '18:23:00', 'Eureka', 'Dewan Seminar', 'annual dinner for final year student ', 'Pending'),
(8, 'KHAIRUL ANWAR', '012-5444665', 'akajihadist@gmail.com', 'Lunch', '2026-03-31', '21:32:00', 'Eureka', 'Dewan Seminar', '', 'Pending');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
